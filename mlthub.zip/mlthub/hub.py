import argparse
import io
import os
import sys
from pathlib import Path
os.environ.setdefault('PYGAME_HIDE_SUPPORT_PROMPT', '1')
import pygame
import tool
try:
    import game_object
except Exception as exc:
    game_object = None
    print('[hub] game_object 不可用: {}'.format(exc))
try:
    import todo as todo_module
except Exception as exc:
    todo_module = None
    print('[hub] todo 不可用({})，改用内置简易逻辑'.format(exc))
SCREEN_SIZE = (800, 600)
DEFAULT_DES = 'description.des'
DEFAULT_FONT_NAME = os.path.join('resource', 'font.otf')
DEFAULT_FONT_SIZE = 24
MARGIN = 20
DEFAULT_ALLOW_AUTO_CREATE = False
_global_font = None
def init_global_font(script_dir, font_name=DEFAULT_FONT_NAME, font_size=DEFAULT_FONT_SIZE):
    global _global_font
    if not pygame.font.get_init():
        pygame.font.init()
    font_path = os.path.join(str(script_dir), font_name)
    try:
        _global_font = pygame.font.Font(font_path, font_size)
        print('[hub] 成功加载自定义字体: {}'.format(font_path))
        return _global_font
    except Exception as e:
        print('[hub] 加载自定义字体 {} 失败: {}，尝试系统字体兜底'.format(font_path, e))
    for sys_font_name in ('SimHei', 'Microsoft YaHei', 'PingFang HK', 'WenQuanYi Micro Hei'):
        try:
            _global_font = pygame.font.SysFont(sys_font_name, font_size)
            print('[hub] 使用系统字体兜底: {}'.format(sys_font_name))
            return _global_font
        except Exception:
            continue
    try:
        _global_font = pygame.font.Font(None, font_size)
        print('[hub] 使用 pygame 默认字体（可能无法显示中文）')
    except Exception as e:
        print('[hub] 字体初始化彻底失败: {}'.format(e))
        _global_font = None
    return _global_font
def get_global_font():
    return _global_font
def load_des_images(script_dir, des_name=DEFAULT_DES, consume=False):
    des_path = os.path.join(str(script_dir), des_name)
    images, count = tool.parse_to_images(des_path, consume=consume, verbose=True)
    surfaces = []
    for name, img in images:
        data = tool.to_bytes(img, fmt='JPEG')
        surface = pygame.image.load(io.BytesIO(data), name + '.jpg')
        if surface.get_alpha() is None and pygame.display.get_surface() is not None:
            surface = surface.convert()
        surfaces.append((name, surface))
    return surfaces, count
def build_objects(script_dir, surfaces, allow_auto_create=DEFAULT_ALLOW_AUTO_CREATE):
    objects = []
    if game_object is not None:
        try:
            objects = game_object.load_all_objects(Path(script_dir))
        except Exception as exc:
            print('[hub] 读取 object 目录失败: {}'.format(exc))
            objects = []
    refs = {}
    def register(key, obj):
        if not key:
            return
        bucket = refs.setdefault(key, [])
        if obj not in bucket:
            bucket.append(obj)
    for obj in objects:
        image_name = getattr(obj, 'image_name', None)
        if image_name:
            register(os.path.splitext(image_name)[0], obj)
    for obj in objects:
        register(getattr(obj, 'name', None), obj)
    groups = {}
    order = []
    for name, surface in surfaces:
        if name not in groups:
            groups[name] = []
            order.append(name)
        groups[name].append(surface)
    created = []
    assigned = set()
    for name in order:
        surf_list = groups[name]
        want = [o for o in refs.get(name, []) if id(o) not in assigned]
        for i, obj in enumerate(want):
            surface = surf_list[i] if i < len(surf_list) else surf_list[-1]
            attach_image(obj, name, surface)
            assigned.add(id(obj))
        for i in range(len(want), len(surf_list)):
            if not allow_auto_create or game_object is None:
                print('[hub] 跳过未绑定预定义对象的资源: {} (第 {} 张)，不创建 GameObject'.format(name, i + 1))
                continue
            obj = game_object.GameObject()
            obj.name = name if i == 0 else '{}_{}'.format(name, i)
            objects.append(obj)
            attach_image(obj, name, surf_list[i])
            assigned.add(id(obj))
            refs.setdefault(name, []).append(obj)
            created.append(obj)
    if created:
        cell = max(max(o.image.get_width(), o.image.get_height()) for o in created) + 40
        cols = max(1, (SCREEN_SIZE[0] - MARGIN) // cell)
        for i, obj in enumerate(created):
            col, row = i % cols, i // cols
            obj.set_position(MARGIN + col * cell, MARGIN + row * cell)
    return objects
def attach_image(obj, name, surface):
    obj.set_image(name)
    obj.image_name = name
    obj.image = surface.copy() if hasattr(surface, 'copy') else surface
def _fallback_update(objects, tick):
    for obj in objects:
        if not hasattr(obj, 'x'):
            obj.x, obj.y = 0, 0
def sort_objects_by_id(objects):
    def sort_key(obj):
        obj_id = getattr(obj, 'id', None)
        if isinstance(obj_id, bool):
            obj_id = int(obj_id)
        if isinstance(obj_id, (int, float)):
            return (0, obj_id)
        return (1, 0)
    return sorted(objects, key=sort_key)
def run(script_dir, frames=None, consume=False, des_name=DEFAULT_DES, save_frame=None,
        font_name=DEFAULT_FONT_NAME, font_size=DEFAULT_FONT_SIZE,
        allow_auto_create=DEFAULT_ALLOW_AUTO_CREATE):
    pygame.init()
    init_global_font(script_dir, font_name=font_name, font_size=font_size)
    screen = pygame.display.set_mode(SCREEN_SIZE)
    pygame.display.set_caption('Card Engine')
    surfaces, count = load_des_images(script_dir, des_name=des_name, consume=consume)
    print('[hub] des 解析完成，该 des 共 {} 个 object'.format(count))
    objects = build_objects(script_dir, surfaces, allow_auto_create=allow_auto_create)
    objects = sort_objects_by_id(objects)
    print('[hub] 渲染顺序（按 id 升序）: {}'.format(
        [(getattr(o, 'id', None), getattr(o, 'name', None)) for o in objects]))
    resource_dir = Path(script_dir) / 'resource'
    print('[hub] 游戏对象 {} 个；resource 目录: {}'.format(
        len(objects), '已存在(未新建)' if resource_dir.exists() else '未创建'))
    clock = pygame.time.Clock()
    tick = 0
    running = True
    while running:
        tick += 1
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        if todo_module is not None:
            todo_module.update(objects, tick)
        else:
            _fallback_update(objects, tick)
        screen.fill((255, 255, 255))
        for obj in objects:
            image = getattr(obj, 'image', None)
            text = getattr(obj, 'text_surface', None)
            if image is not None:
                screen.blit(image, (obj.x, obj.y))
            elif text is not None:
                screen.blit(text, (obj.x, obj.y))
            else:
                pygame.draw.rect(screen, (200, 200, 200), (obj.x, obj.y, 50, 50))
        pygame.display.flip()
        if save_frame and tick == 1:
            pygame.image.save(screen, str(save_frame))
            print('[hub] 首帧截图: {}'.format(save_frame))
        clock.tick(30)
        if frames is not None and tick >= frames:
            running = False
    pygame.quit()
    return count
def main(argv=None):
    parser = argparse.ArgumentParser(description='des 驱动的游戏入口')
    parser.add_argument('--des', default=DEFAULT_DES, help='des 文件名')
    parser.add_argument('--font', default=DEFAULT_FONT_NAME, help='自定义字体文件名，默认读取当前目录下 font.otf')
    parser.add_argument('--font-size', type=int, default=DEFAULT_FONT_SIZE, help='全局字体大小')
    parser.add_argument('--frames', type=int, default=None, help='只跑 N 帧后退出（自检用）')
    parser.add_argument('--consume', action='store_true', help='消费 des 指令行（默认关闭；即使打开，description.des 文件也保留）')
    parser.add_argument('--keep-des', action='store_true', help='【默认即此行为】保留 description.des，兼容旧参数')
    parser.add_argument('--auto-create', action='store_true',
                        help='为没有匹配到预定义对象的图片资源自动补建 GameObject（默认关闭，避免废弃资源凭空产出对象）')
    parser.add_argument('--save-frame', default=None, help='首帧截图保存路径')
    args = parser.parse_args(argv)
    script_dir = Path(__file__).resolve().parent
    run(
        script_dir,
        frames=args.frames,
        consume=args.consume and not args.keep_des,
        des_name=args.des,
        save_frame=args.save_frame,
        font_name=args.font,
        font_size=args.font_size,
        allow_auto_create=args.auto_create,
    )
    return 0
if __name__ == '__main__':
    sys.exit(main())
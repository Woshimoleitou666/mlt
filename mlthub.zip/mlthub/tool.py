import io,os
from PIL import Image,ImageDraw
DEFAULT_DES='description.des'

def _rrect(draw,x1,y1,x2,y2,r,g,b,rr):
    left,upper=min(x1,x2),min(y1,y2)
    right,lower=max(x1,x2),max(y1,y2)
    w,h=right-left,lower-upper
    if w<=0 or h<=0:return
    draw.rounded_rectangle([left,upper,right,lower],radius=min(w,h)*rr,fill=(r,g,b))

def to_bytes(image,fmt='JPEG',quality=95):
    out=image
    if fmt.upper() in ('JPEG','JPG') and out.mode!='RGB':
        bg=Image.new('RGB',out.size,(255,255,255))
        bg.paste(out,mask=out.split()[3] if out.mode=='RGBA' else None)
        out=bg
    buf=io.BytesIO()
    out.save(buf,fmt,quality=quality)
    return buf.getvalue()

def parse_to_images(input_file=DEFAULT_DES,consume=False,verbose=True):
    if not os.path.exists(input_file):
        if verbose:print('[tool] 找不到 des 文件: '+str(input_file))
        return [],0
    with open(input_file,'r',encoding='utf-8') as f:raw=f.readlines()
    images,blocks,dropped,current,draw,current_name,pending_name,pending_start,cur_start,count=[],[],0,None,None,None,None,None,None,0

    def finish(end):
        nonlocal current,draw,current_name,cur_start,count,dropped
        if current is None:return
        if current_name:
            images.append((current_name,current))
            blocks.append((cur_start,end))
            count+=1
            if verbose:print('[tool] 图片资源 #{}: {} ({}x{})'.format(count,current_name,current.width,current.height))
        else:
            dropped+=1
            if verbose:print('[tool] 跳过无名块（{}x{}，第 {} 行起）：des 不能创建对象，请用 [名字] 指明要挂图的预定义对象'.format(current.width,current.height,(cur_start or 0)+1))
        current,draw,current_name,cur_start=None,None,None,None

    for idx,raw_line in enumerate(raw):
        line=raw_line.strip()
        if not line or line.startswith('#'):continue
        if line.startswith('[') and line.endswith(']'):
            pending_name,pending_start=line[1:-1].strip(),idx
            continue
        try:params=[float(x) for x in line.split()]
        except ValueError:
            if verbose:print('[tool] 跳过无法解析的行: '+line)
            continue
        num_params=len(params)
        if num_params==2:
            finish(idx)
            pw,ph=int(params[0]),int(params[1])
            cur_start=pending_start if pending_start is not None else idx
            current_name=pending_name
            pending_name,pending_start=None,None
            current=Image.new('RGBA',(pw,ph),(255,255,255,255))
            draw=ImageDraw.Draw(current)
            if verbose:print('[tool] 新建画布 {}x{} -> {}'.format(pw,ph,(current_name+'.jpg') if current_name else '无名块(稍后跳过)'))
        elif num_params==8:
            if current is None:continue
            sx,sy,ex,ey=map(int,params[:4])
            r,g,b=map(int,params[4:7])
            _rrect(draw,sx,sy,ex,ey,r,g,b,params[7])
        elif num_params==12:
            if current is None:continue
            sx,sy,ex,ey=map(int,params[:4])
            fr,fg,fb=map(int,params[4:7])
            bw=int(params[7])
            br,bg,bb=map(int,params[8:11])
            rr=params[11]
            _rrect(draw,sx,sy,ex,ey,br,bg,bb,rr)
            if ex-bw>sx+bw and ey-bw>sy+bw:_rrect(draw,sx+bw,sy+bw,ex-bw,ey-bw,fr,fg,fb,rr)
        else:
            if verbose:print('[tool] 未知参数数量 {}: {}'.format(num_params,line))
    finish(len(raw))
    if consume and blocks:
        drop=set()
        for start,end in blocks:drop.update(range(start,end))
        rest=[ln for i,ln in enumerate(raw) if i not in drop]
        with open(input_file,'w',encoding='utf-8') as f:f.writelines(rest)
        if verbose:print('[tool] 已消费 {} 个图片块的指令行，des 文件保留'.format(len(blocks)))
    elif verbose:print('[tool] description.des 已完整保留: '+str(input_file))
    if verbose:print('[tool] 本次解析出 {} 条图片资源，跳过无名块 {} 个；本模块不创建任何游戏对象'.format(count,dropped))
    return images,count

if __name__=='__main__':
    imgs,n=parse_to_images(DEFAULT_DES)
    print('共 {} 条图片资源（不创建对象）: {}'.format(n,[name for name,_ in imgs]))
import json
import pygame
from pathlib import Path
class GameObject:
    def __init__(self):
        self.x,self.y=0,0
        self.origin_x,self.origin_y=0,0
        self.image_name=None
        self.image=None
        self.name=None
        self.text_config=None
        self.text_surface=None
        self.scene=0
        self.alpha=255
        self.id=None
    def set_position(self,x,y):
        self.x,self.y=x,y
        self.origin_x,self.origin_y=x,y
    def set_image(self,name):
        self.image_name=name
    def set_alpha(self,value):
        try:
            alpha_val=int(value)
            if 0<=alpha_val<=255:self.alpha=alpha_val
            else:self.alpha=max(0,min(255,alpha_val))
        except (TypeError,ValueError):
            self.alpha=255
    def apply_alpha(self):
        if self.image is not None:self.image.set_alpha(self.alpha)
        if self.text_surface is not None:self.text_surface.set_alpha(self.alpha)
    def set_scene(self,scene_id):
        try:self.scene=int(scene_id)
        except (TypeError,ValueError):self.scene=scene_id
    def set_id(self,id_value):
        if id_value is None:self.id=None
        else:
            try:self.id=int(id_value)
            except (TypeError,ValueError):self.id=id_value
    def set_text_config(self,config):
        if isinstance(config,str):self.text_config={"content":config,"font_size":24}
        elif isinstance(config,dict):
            content=config.get("content",config.get("text",""))
            size=config.get("font_size",24)
            if content:self.text_config={"content":content,"font_size":size}
            else:self.text_config=None
class Button(GameObject):
    def __init__(self):
        super().__init__()
        self.key=None
    def set_key(self,key_value):
        self.key=key_value
def interpret_position(obj,value):
    x,y=value.get("x",0),value.get("y",0)
    obj.set_position(x,y)
def interpret_image(obj,value):
    name=value.get("name")
    if name:obj.set_image(name)
def interpret_text(obj,value):
    obj.set_text_config(value)
def interpret_scene(obj,value):
    obj.set_scene(value)
def interpret_id(obj,value):
    obj.set_id(value)
def interpret_alpha(obj,value):
    obj.set_alpha(value)
def interpret_key(obj,value):
    if hasattr(obj,'key'):obj.set_key(value)
def interpret(obj,data):
    if "position" in data:interpret_position(obj,data["position"])
    if "image" in data:interpret_image(obj,data["image"])
    if "text" in data:interpret_text(obj,data["text"])
    if "scene" in data:interpret_scene(obj,data["scene"])
    if "id" in data:interpret_id(obj,data["id"])
    if "alpha" in data:interpret_alpha(obj,data["alpha"])
    if "key" in data:interpret_key(obj,data["key"])
def load_all_objects(script_dir):
    objects_folder=script_dir/"object"
    resource_folder=script_dir/"resource"
    game_objects=[]
    default_font_path=resource_folder/"font.otf"
    if not objects_folder.exists():return game_objects
    font_cache={}
    def get_font(size):
        if size in font_cache:return font_cache[size]
        font_obj=None
        if default_font_path.exists():
            try:font_obj=pygame.font.Font(str(default_font_path),size)
            except:pass
        if font_obj is None:
            try:font_obj=pygame.font.SysFont(None,size)
            except:return None
        font_cache[size]=font_obj
        return font_obj
    for json_path in objects_folder.glob("*.json"):
        try:
            with open(json_path,"r",encoding="utf-8") as f:data=json.load(f)
            obj_class_type=data.get("class","gameobject").lower()
            if obj_class_type=="button":obj=Button()
            else:obj=GameObject()
            obj.name=json_path.stem
            interpret(obj,data)
            if obj.image_name:
                image_path=resource_folder/obj.image_name
                if image_path.exists():
                    try:
                        loaded_image=pygame.image.load(str(image_path))
                        if loaded_image.get_alpha() is None:obj.image=loaded_image.convert_alpha()
                        else:obj.image=loaded_image
                        if obj.alpha<255:obj.image.set_alpha(obj.alpha)
                    except pygame.error as e:obj.image=None
                else:obj.image=None
            if obj.text_config and not obj.image:
                content,size=obj.text_config["content"],obj.text_config["font_size"]
                font=get_font(size)
                if font:
                    try:
                        text_surf=font.render(content,True,(0,0,0))
                        if obj.alpha<255:
                            obj.text_surface=text_surf.convert_alpha()
                            obj.text_surface.set_alpha(obj.alpha)
                        else:obj.text_surface=text_surf
                    except:obj.text_surface=None
            game_objects.append(obj)
        except:pass
    return game_objects
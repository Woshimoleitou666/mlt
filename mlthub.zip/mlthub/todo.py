import game_object
import keyboard
scene=0
OFFSCREEN_POS=(1200,900)
_trigger_locked=False
ENDSCENE_0=False
ENDSCENE_0_CNT=0
def StartButton():
    global ENDSCENE_0
    ENDSCENE_0=True
def update(game_objects, tick):
    global scene,_trigger_locked,ENDSCENE_0_CNT
    any_key_pressed=False
    for obj in game_objects:
        if obj.alpha<255:
            obj.set_alpha(min(255,obj.alpha+8.5))
            obj.apply_alpha()
        if ENDSCENE_0 and scene==0:
            obj.set_alpha(min(255,obj.alpha-17))
            obj.apply_alpha()
            if obj.alpha==0:
                ENDSCENE_0_CNT+=1
            if ENDSCENE_0_CNT==3:
                scene=1
        obj_scene=getattr(obj,"scene",None)
        if obj_scene!=scene:
            obj.x,obj.y=OFFSCREEN_POS
            continue
        obj.x,obj.y=obj.origin_x,obj.origin_y
        if isinstance(obj,game_object.Button):
            if obj.key is not None and keyboard.is_pressed(obj.key):
                any_key_pressed=True
                if not _trigger_locked and obj.alpha>=255:
                    func_name=obj.name
                    func=globals().get(func_name)
                    if callable(func):
                        func()
                        _trigger_locked=True
                    else:
                        print(f"Function {func_name} not found or not callable")
    if not any_key_pressed:
        _trigger_locked=False
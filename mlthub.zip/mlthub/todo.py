import game_object
import keyboard
scene=0
toscene=0
OFFSCREEN_POS=(1200,900)
_trigger_locked=False
STARTSCENE=[True,False]
STARTSCENE_CNT=[0,0]
ENDSCENE=[False,False]
ENDSCENE_CNT=[0,0]
OBJECT_NUMBER=[3,3]
def StartButton():
    global toscene,ENDSCENE
    toscene,ENDSCENE[0]=1,True
def EndScene():
    global scene,toscene,STARTSCENE
    if scene==0:
        scene,STARTSCENE[toscene]=toscene,True
def update(game_objects,tick):
    global scene,_trigger_locked,ENDSCENE,STARTSCENE,ENDSCENE_CNT,STARTSCENE_CNT,OBJECT_NUMBER
    any_key_pressed=False
    for obj in game_objects:
        if STARTSCENE[obj.scene] and scene==obj.scene  and obj.alpha<255:
            obj.set_alpha(min(255,obj.alpha+8.5))
            obj.apply_alpha()
            if obj.alpha==255:
                STARTSCENE_CNT[obj.scene]+=1
            if STARTSCENE_CNT[obj.scene]==OBJECT_NUMBER[obj.scene]:
                STARTSCENE[obj.scene]=False
        if ENDSCENE[obj.scene] and scene==0:
            obj.set_alpha(max(0,obj.alpha-17))
            obj.apply_alpha()
            if obj.alpha==0:
                ENDSCENE_CNT[obj.scene]+=1
            if ENDSCENE_CNT[obj.scene]==OBJECT_NUMBER[obj.scene]:
                EndScene()
        obj_scene=getattr(obj,"scene",None)
        if obj_scene!=scene:
            obj.x,obj.y=OFFSCREEN_POS
            continue
        obj.x,obj.y=obj.origin_x,obj.origin_y
        if isinstance(obj,game_object.Button):
            if obj.key is not None and keyboard.is_pressed(obj.key):
                any_key_pressed=True
                if not _trigger_locked and obj.alpha>=255:
                    func_name=obj.name
                    func=globals().get(func_name)
                    if callable(func):
                        func()
                        _trigger_locked=True
                    else:
                        print(f"Function {func_name} not found or not callable")
    if not any_key_pressed:
        _trigger_locked=False